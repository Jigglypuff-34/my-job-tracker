import React from "react";
import MainContainer from "./containers/MainContainer.jsx";

function App() {
  return (
    <>
      <MainContainer />
    </>
  );
}

export default App;

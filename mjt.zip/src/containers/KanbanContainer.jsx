/* eslint-disable linebreak-style */
import React from "react";
import { Board } from "../board-components/Board.jsx";

function Kanban() {
  return <Board />;
}

export default Kanban;

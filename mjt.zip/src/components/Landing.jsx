/* eslint-disable linebreak-style */
import React from "react";
import { Box } from "@mui/material";

function Landing() {
  return (
    <Box className="Landing">
      LANDING AND HERO
    </Box>
  );
}

export default Landing;

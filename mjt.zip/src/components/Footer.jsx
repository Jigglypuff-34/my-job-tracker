/* eslint-disable linebreak-style */
import React from "react";
import { Box } from "@mui/material";

function Footer() {
  return (
    <Box className="footer">
      FOOTER
    </Box>
  );
}

export default Footer;

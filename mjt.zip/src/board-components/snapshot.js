export const draggableSnapshot = {
  isDragging: true,
  draggingOver: "column-1",
};

export const droppableSnapshot = {
  isDraggingOver: true,
  draggingOverWith: "task-1",
};
